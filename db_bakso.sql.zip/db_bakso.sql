-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 18, 2017 at 07:20 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_bakso`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menu`
--

CREATE TABLE IF NOT EXISTS `tbl_menu` (
  `menuid` varchar(8) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `harga` int(50) NOT NULL,
  PRIMARY KEY (`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_menu`
--

INSERT INTO `tbl_menu` (`menuid`, `nama`, `harga`) VALUES
('BKS001', 'BAKSO BIASA', 10000),
('BKST001', 'BAKSO TELUR', 14000),
('KLNG', 'KELANTING', 1000),
('KRPK001', 'KERUPUK', 1000),
('KRPK002', 'KERUPUK PANGSIT', 2000),
('MA001', 'MIE AYAM', 8000),
('MB001', 'MIE AYAM BAKSO KECIL', 10000),
('MB002', 'MIE AYAM BAKSO SEDANG', 12000),
('MB003', 'MIE AYAM BAKSO BESAR', 14000),
('MNM001', 'ES TAWAR', 1000),
('MNM002', 'ES JERUK', 5000),
('MNM003', 'FRESTEA', 3000),
('MNM004', 'FREASTEA KOMBINASI ES', 4000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE IF NOT EXISTS `tbl_transaksi` (
  `namaPembeli` varchar(100) NOT NULL,
  `namaBarang` varchar(100) NOT NULL,
  `jumlahBeli` varchar(100) NOT NULL,
  `totalBayar` int(50) NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`namaPembeli`, `namaBarang`, `jumlahBeli`, `totalBayar`, `tanggal`) VALUES
('aprian', 'BKST001+NULL+NULL+NULL+NULL+NULL+NULL+NULL+NULL', '28000+0+0+0+0+0+0+0+0+', 28000, '2017-01-13 12:10:44'),
('bambang', 'BKST001, MNM001, -, -, -, -, -, -, -', '28000, 0, 2000, 0, 0, 0, 0, 0, 0, ', 30000, '2017-01-13 12:18:12'),
('wayan', 'BKST001, MNM004, -, -, -, -, -, -, -', '14000, 0, 4000, 0, 0, 0, 0, 0, 0, ', 18000, '2017-01-14 14:45:29'),
('riki nuralim', 'MB003, MNM003, -, -, -, -, -, -, -', '28000, 0, 6000, 0, 0, 0, 0, 0, 0, ', 34000, '2017-01-14 15:03:15'),
('bolang', 'MB001, KLNG, MNM004, -, -, -, -, -, -', '20000, 8000, 2000, 0, 0, 0, 0, 0, 0, ', 30000, '2017-01-14 15:05:32'),
('tegar', 'MB003, MNM004, KRPK002, -, -, -, -, -, -', '28000, 8000, 8000, 0, 0, 0, 0, 0, 0, ', 44000, '2017-01-17 03:24:40'),
('fikri', 'BKST001, MNM004, KRPK001, -, -, -, -, -, -', '42000, 8000, 12000, 0, 0, 0, 0, 0, 0, ', 62000, '2017-01-17 04:18:17');
